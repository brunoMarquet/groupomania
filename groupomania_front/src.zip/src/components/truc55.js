import React, { useEffect, useState } from "react";
import { nyTimesApi } from "../services/Api";

const Main = () => {
  const [isLoading, setIsLoading] = useState(true);
  const [data, setData] = useState([]);

  useEffect(
    () => {
      // Create function inside useEffect so that the function is only
      // created everytime the useEffect runs and not every render.
      const fetchData = async () => {
        const result = await nyTimesApi();
        setData(result);
        setIsLoading(false);

        // setData will update state asynchronously.
        // Log the value stored instead.
        console.log(result.results);
      };

      //Run data fetching function.
      fetchData();
    },
    // Both of these are set functions created by useState and will
    // not change for the life of the component, but adding them to
    // the dependency array will make your linter happy.

    // Do not need to check isLoading as it is always true on component
    // mount.
    [setData, setIsLoading]
  );

  return <div className="main">work</div>;
};

export default Main;
