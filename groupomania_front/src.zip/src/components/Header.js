//import logo from "./assets/logoGroupo.png";
import logo from "../assets/logoGroupo.png";
import Login2 from "./Login2";

const Header = () => {
  return (
    <header>
      <p> mon header...</p>
      <img src={logo} alt="Logo" /> <Login2 />
    </header>
  );
};

export default Header;

/***
 *
 */
